// appshell.js

// Tampilkan elemen utama kerangka aplikasi
export function initializeAppShell() {
  document.querySelector('.header');
  document.querySelector('.footer__content');
}
