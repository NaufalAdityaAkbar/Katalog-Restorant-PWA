export { default as showHomePage } from './home';
export { default as showDetailPage } from './detail';
