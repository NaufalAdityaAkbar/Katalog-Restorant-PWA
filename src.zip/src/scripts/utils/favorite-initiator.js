import { getAllFavorites, saveRestaurant, removeFavorite } from './db';

const FavoriteInitiator = {
  async init() {
    try {
      const favoriteContainer = document.getElementById('Favorite');
      if (!favoriteContainer) return;

      favoriteContainer.style.display = 'block';
      await this.renderFavorites();
    } catch (error) {
      console.error('Error initializing favorites:', error);
    }
  },

  async renderFavorites() {
    try {
      const favoriteContainer = document.getElementById('Favorite');
      const favorites = await getAllFavorites();

      const favoritesArray = Array.isArray(favorites) ? favorites : [];

      favoriteContainer.innerHTML = `
        <div class="favorite-container">
          <h2 class="favorite-title">Restoran Favorit</h2>
          ${favoritesArray.length === 0
    ? `<div class="favorite-empty">
                 <h2>Tidak ada restoran favorit</h2>
                 <p>Silakan tambahkan restoran ke daftar favorit Anda</p>
               </div>`
    : `<div class="posts favorite-list">
                 ${favoritesArray.map((restaurant) => `
                   <article class="post-item">
                     <img class="post-item__thumbnail" 
                          src="https://restaurant-api.dicoding.dev/images/medium/${restaurant.pictureId}" 
                          alt="${restaurant.name}">
                     <div class="post-item__content">
                       <h1 class="post-item__title">${restaurant.name}</h1>
                       <p class="post-item__city">Kota: ${restaurant.city}</p>
                       <p class="post-item__rating">Rating: ${restaurant.rating}★</p>
                       <p class="post-item__description">${restaurant.description}</p>
                       <div class="cta-wrapper">
                         <button 
                           class="btn-detail" 
                           data-id="${restaurant.id}"
                           aria-label="Lihat detail ${restaurant.name}">
                           Lihat Detail
                         </button>
                       </div>
                     </div>
                   </article>
                 `).join('')}
               </div>`
}
        </div>
      `;

      const detailButtons = favoriteContainer.querySelectorAll('.btn-detail');
      detailButtons.forEach((button) => {
        button.addEventListener('click', () => {
          const id = button.dataset.id;
          window.location.hash = `/detail/${id}`;
        });
      });

    } catch (error) {
      console.error('Error rendering favorites:', error);
      const favoriteContainer = document.getElementById('Favorite');
      favoriteContainer.innerHTML = `
        <div class="favorite-container">
          <h2 class="favorite-title">Restoran Favorit</h2>
          <div class="favorite-empty">
            <h2>Terjadi kesalahan</h2>
            <p>Maaf, tidak dapat memuat daftar favorit</p>
          </div>
        </div>
      `;
    }
  },

  async addToFavorite(restaurant) {
    await saveRestaurant(restaurant);
    // Dispatch event ketika restoran difavoritkan
    document.dispatchEvent(new CustomEvent('restaurant-favorited', {
      detail: { restaurant },
    }));
  },

  async removeFromFavorite(restaurant) {
    await removeFavorite(restaurant.id);
    // Dispatch event ketika restoran dihapus dari favorit
    document.dispatchEvent(new CustomEvent('restaurant-unfavorited', {
      detail: { restaurant },
    }));
  },
};

export default FavoriteInitiator;