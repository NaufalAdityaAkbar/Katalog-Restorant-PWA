import app from '../index';
import { loadRestaurantDetails } from '../components/restaurantDetail';
import FavoriteInitiator from '../utils/favorite-initiator';

const routes = {
  '/': () => {
    app.showHomePage();
    app.loadRestaurants();
  },
  '/detail/:id': (id) => {
    console.log('Loading detail for restaurant:', id);
    if (!id) {
      console.error('No restaurant ID provided');
      return;
    }

    document.querySelector('#home').style.display = 'none';
    document.querySelector('#Story').style.display = 'none';
    document.querySelector('#Restaurant').style.display = 'none';
    document.querySelector('#Favorite').style.display = 'none';
    document.querySelector('#restaurantDetailContainer').style.display = 'block';
    document.querySelector('.content').style.display = 'block';
    document.querySelector('.back-button').style.display = 'block';

    document.querySelector('#restaurantDetailContainer').innerHTML = 'Loading...';

    loadRestaurantDetails(id)
      .catch((error) => {
        console.error('Error loading restaurant details:', error);
        document.querySelector('#restaurantDetailContainer').innerHTML = `
          <div class="error-message">
            Maaf, terjadi kesalahan saat memuat detail restoran.
            <br>
            <button onclick="window.location.hash='/'">Kembali ke Beranda</button>
          </div>
        `;
      });
  },
  '/favorite': () => {
    document.querySelector('#home').style.display = 'none';
    document.querySelector('#Story').style.display = 'none';
    document.querySelector('#Restaurant').style.display = 'none';
    document.querySelector('#restaurantDetailContainer').style.display = 'none';
    document.querySelector('#Favorite').style.display = 'block';
    document.querySelector('.content').style.display = 'block';
    document.querySelector('.back-button').style.display = 'block';
    FavoriteInitiator.init();
  },
};

export default routes;