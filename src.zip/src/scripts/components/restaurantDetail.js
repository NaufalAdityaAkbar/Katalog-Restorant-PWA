import { saveRestaurant, getFavoriteRestaurant, removeFavorite } from '../utils/db';
import CONFIG from '../global/config';

export async function submitReview(data) {
  try {
    const response = await fetch(`${CONFIG.BASE_URL}review`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    const responseData = await response.json();
    return responseData;
  } catch {
    throw new Error('Gagal mengirim review');
  }
}

// Tambahkan fungsi untuk menampilkan toast notification
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

export async function loadRestaurantDetails(id) {
  try {
    const response = await fetch(`${CONFIG.BASE_URL}detail/${id}`);
    if (!response.ok) {
      throw new Error('Restaurant not found');
    }

    const { restaurant } = await response.json();
    const isFavorited = await getFavoriteRestaurant(id);

    document.getElementById('restaurantDetailContainer').innerHTML = `
      <div class="restaurant-detail">
        <div class="restaurant-header">
          <h1 class="restaurant-title">${restaurant.name}</h1>
          <div class="restaurant-actions">
            <div class="restaurant-rating">⭐️ ${restaurant.rating}</div>
            <button 
              class="favorite-btn ${isFavorited ? 'favorited' : ''}"
              aria-label="${isFavorited ? 'Hapus dari favorit' : 'Tambah ke favorit'}"
            >
              <i class="fas ${isFavorited ? 'fa-heart' : 'fa-heart'}"></i>
            </button>
          </div>
        </div>
        
        <div class="restaurant-main">
          <img class="restaurant-image" src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt="${restaurant.name}" />
          
          <div class="restaurant-info-grid">
            <div class="info-card location">
              <h3>Lokasi</h3>
              <p class="city"><i class="fas fa-city"></i> ${restaurant.city}</p>
              <p class="address"><i class="fas fa-map-marker-alt"></i> ${restaurant.address}</p>
            </div>
            
            <div class="info-card description">
              <h3>Tentang</h3>
              <p>${restaurant.description}</p>
            </div>
          </div>
          
          <div class="menu-grid">
            <div class="menu-card foods">
              <h3><i class="fas fa-utensils"></i> Menu Makanan</h3>
              <ul>
                ${restaurant.menus.foods.map((food) => `<li>${food.name}</li>`).join('')}
              </ul>
            </div>
            
            <div class="menu-card drinks">
              <h3><i class="fas fa-coffee"></i> Menu Minuman</h3>
              <ul>
                ${restaurant.menus.drinks.map((drink) => `<li>${drink.name}</li>`).join('')}
              </ul>
            </div>
          </div>
          
          <div class="reviews-section">
            <h3><i class="fas fa-comments"></i> Ulasan Pelanggan</h3>
            
            <form id="reviewForm" class="review-form">
              <h4>Tambah Ulasan</h4>
              <input type="hidden" name="id" value="${restaurant.id}">
              <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" id="name" name="name" required>
              </div>
              <div class="form-group">
                <label for="review">Ulasan</label>
                <textarea id="review" name="review" required></textarea>
              </div>
              <button type="submit" class="submit-review">Kirim Ulasan</button>
            </form>

            <div class="reviews-container">
              ${restaurant.customerReviews.map((review) => `
                <div class="review-card">
                  <div class="review-header">
                    <p class="review-name"><i class="fas fa-user"></i> ${review.name}</p>
                    <p class="review-date">${review.date}</p>
                  </div>
                  <p class="review-text">${review.review}</p>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;

    // Tambahkan event listener untuk tombol favorit
    const favoriteBtn = document.querySelector('.favorite-btn');
    favoriteBtn.addEventListener('click', async () => {
      try {
        if (isFavorited) {
          await removeFavorite(id);
          favoriteBtn.classList.remove('favorited');
          favoriteBtn.querySelector('i').classList.replace('fa-heart', 'fa-heart');
          showToast('Dihapus dari favorit');
        } else {
          await saveRestaurant(restaurant);
          favoriteBtn.classList.add('favorited');
          favoriteBtn.querySelector('i').classList.replace('fa-heart', 'fa-heart');
          showToast('Ditambahkan ke favorit');
        }
      } catch (error) {
        showToast('Gagal mengubah status favorit');
        console.error('Error toggling favorite:', error);
      }
    });

    // Add event listener for review form
    document.getElementById('reviewForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const reviewData = {
        id: formData.get('id'),
        name: formData.get('name'),
        review: formData.get('review'),
      };

      try {
        await submitReview(reviewData);
        // Reload restaurant details to show new review
        await loadRestaurantDetails(restaurant.id);
        alert('Review berhasil ditambahkan!');
      } catch {
        alert('Gagal menambahkan review');
      }
    });

  } catch (error) {
    console.error('Error loading restaurant details:', error);
    throw error;
  }
}